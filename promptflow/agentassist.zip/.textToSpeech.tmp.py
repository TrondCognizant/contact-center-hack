from promptflow import tool # default python module

# from https://learn.microsoft.com/en-us/azure/ai-services/speech-service/get-started-text-to-speech?tabs=macos%2Cterminal&pivots=programming-language-python
import os 
import azure.cognitiveservices.speech as speechsdk

# The inputs section will change based on the arguments of the tool function, after you save the code
# Adding type to arguments and return value will help the system show the types properly
# Please update the function name/signature per need
@tool
def generate_speech(input1: str):
    SPEECH_KEY = 'FRoLaudusgCbsvhWesFGAKqlYqW67tl6Lga7HEM53aZTfedmpWbpJQQJ99AKACfhMk5XJ3w3AAAYACOGh5kd'
    SPEECH_REGION = 'swedencentral'
    #SPEECH_REGION = 'Sweden Central'
    # This example requires environment variables named "SPEECH_KEY" and "SPEECH_REGION"
    speech_config = speechsdk.SpeechConfig(subscription=os.environ.get(SPEECH_KEY), region=os.environ.get(SPEECH_REGION))
    audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)
    # "694450-speech (SpeechServices, Sweden Central, F0)"

    # The neural multilingual voice can speak different languages based on the input text.
    speech_config.speech_synthesis_voice_name='en-US-AvaMultilingualNeural'

    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

    # Get text from the console and synthesize to the default speaker.
    #print("Enter some text that you want to speak >")
    text = "Say something" #input1
    speech_synthesis_result = speech_synthesizer.speak_text_async(text).get()

    if speech_synthesis_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print("Speech synthesized for text [{}]".format(text))
    elif speech_synthesis_result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = speech_synthesis_result.cancellation_details
        print("Speech synthesis canceled: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            if cancellation_details.error_details:
                print("Error details: {}".format(cancellation_details.error_details))
                print("Did you set the speech resource key and region values?")